<?php
if(isset($_POST["login"])){
session_start();
include 'config.php';
$facultyid = mysqli_real_escape_string($conn,$_POST['username']);
$password = mysqli_real_escape_string($conn,$_POST['password']);

	$sql = "SELECT tblfaculty.fullname,tblfaculty.facultyid FROM tblaccount INNER JOIN tblfaculty ON tblfaculty.facultyid = tblaccount.facultyid WHERE tblaccount.userid = '$facultyid' AND tblaccount.password = '$password' ";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) {
    // output data of each row
    	while($row = mysqli_fetch_assoc($result)) {
 			
 			$_SESSION["facid"] = $row["facultyid"];
 			$_SESSION["fullname"] = $row["fullname"];
 			header('Location:main/schedulepanel.php');		
    		}
		}else{
			header('Location:index.php');	
			$_SESSION['wrongpass'] = 'wrongpass';
		}
	}
?>