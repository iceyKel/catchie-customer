<?php
include '../config.php';
session_start();
if(!isset($_SESSION['facid'])){
  header('location:../index.php');
}
if(!isset($_SESSION['classno'])){
  header('location:schedulepanel.php');
}
 ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="icon" type="image/png" href="image/stilogo.jpg"/>

<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  text-align: center;
  font-size:12px;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 20px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>
</head>


<body>

<!--<div id="mySidenav" class="sidenav"> 
  <div class="logo">     
  </div>
    <a href="schedulepanel.php" onclick="closeNav()"><i class="fa fa-calendar-o"></i> Check Schedule</a>
    <a href="attendancepanel.php" onclick="closeNav()"><i class="fa fa-calendar-check-o"></i> Check Attendance</a>
    <a href="signout.php" onclick="closeNav()"><i class="fa fa-sign-out"></i> Sign-Out</a>
    <a href="#contact" onclick="closeNav()"><i class="fa fa-cloud"></i> About</a>
  
</div>-->

  <div class="main">
  

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close" >&times;</span>   
    <p>Are you sure you want to logout?</p>
    <a href="" style="text-decoration: none;color: black;margin-right: 40px">Cancel</a>
    <a href="classouter.php" style="text-decoration: none;color: black;">Yes</a>
  </div>

</div>

    <table class="header">
      <!--<td><span style="font-size:30px;cursor:pointer" onclick="openNav()"><i class="fa fa-sign-out"></i></span></td>-->
      <td><span style="font-size:30px;cursor:pointer"><i id="myBtn" class="fa fa-sign-out"></i></span></td>
      <td style="width: 70%;">Attendance</td><td style="font-size: 9px">Faculty ID :</td><td style="font-size: 9px">
        <?php echo $_SESSION['facid'];?>          
        </td><td style="font-size: 9px">Faculty Name :</td><td style="font-size: 9px">
        <?php echo $_SESSION['fullname']?>         
        </td>
    </table>
  
  <div>
    <div class="conmain">
        <table class="sectioInfo">
        
     <?php 
      include '../config.php';

      date_default_timezone_set("Asia/Manila"); 

       $sqltime = "SELECT NOW() AS DATE_TIME, DAYNAME(NOW()) AS DYNAME FROM DUAL";
       $restime = mysqli_query($conn, $sqltime);
    if (mysqli_num_rows($restime)){ while ($rowtime = mysqli_fetch_array($restime)) { $deftime=$rowtime['DATE_TIME']; $defnow=$rowtime['DYNAME']; } }
       $daynow = $defnow;
       $daycut = "";
    if (($daynow=="Thursday") || ($daynow=="Sunday") || ($daynow=="TH") || ($daynow=="Thu") ) {
         $daycut = substr($daynow,0,2);
        } else {
         $daycut = substr($daynow,0,2);    
        }
       $datenow = substr($deftime,0,10);
       $timenow = substr($deftime,11,8);
    
         

        $classno = $_SESSION['classno'];
 

        $faid = $_SESSION['facid']; 

    if (!isset($_SESSION['msginsert']) ){
        $_SESSION['msginsert'] = "";
     }
    if (!isset($_SESSION['msgupdate']) ){
        $_SESSION['msgupdate'] = "";  
    }

    if (!isset($_SESSION['warnmessage']) ){
        $_SESSION['warnmessage'] = "";  
    }

     if (!isset($_SESSION['studentname']) ){
        $_SESSION['studentname'] = "";  
    }
      
       if($_SESSION['msgupdate'] == 'true'){
        echo "<div style ='font-size:16px;text-align:center;background-color:#27ae60;color:#ecf0f1;padding:5px 5px 5px 5px'>Updated Successfully!</div>";
          $_SESSION['msgupdate'] = "";
        }elseif($_SESSION['msgupdate'] == 'false'){
        echo "<div style ='font-size:16px;text-align:center;background-color:#e74c3c;color:#ecf0f1';padding:5px 5px 5px 5px'>Failed to Update!</div>"; 
          $_SESSION['msgupdate'] = ""; 
        }

      if($_SESSION['msginsert'] == 'true'){
        echo "<div style ='font-size:16px;text-align:center;background-color:#2980b9;color:#ecf0f1;padding:5px 5px 5px 5px'>Submitted Successfully!</div>";
          $_SESSION['msginsert'] = "";
        }elseif($_SESSION['msginsert'] == 'false'){
        echo "<div style ='font-size:16px;text-align:center;background-color:#e74c3c;color:#ecf0f1';padding:5px 5px 5px 5px'>Failed to Submit!</div>"; 
          $_SESSION['msginsert'] = ""; 
        }


        $sql2 = "SELECT *  FROM tblatt WHERE dateatt = '$datenow' AND dayatt = '$daycut' AND classno = '$classno'";
          $result2 = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result2) > 0) {
          while($row1 = mysqli_fetch_assoc($result2)){
              $studentcounterid = $row1['studentid'];
              $studname = $row1['studentname'];
              $classnocounter = $row1['classno'];
              Require('absentcounter.php');
              $sqlcount = "SELECT count(studentid) FROM tblatt 
                      WHERE studentid = '$studentcounterid' AND classno = '$classnocounter' AND status = 'Absent'";
              $resultcount = mysqli_query($conn, $sqlcount);
               if (mysqli_num_rows($resultcount) > 0) {  
                   while($rowcount = mysqli_fetch_assoc($resultcount)) {
              $absentcounter =  $rowcount['count(studentid)'];
              if($absentcounter >= 3){
          $sqlinsertabsent = "INSERT INTO tblabsentstudent (studentid,studentname) values ('$studentcounterid','$studname')";
           mysqli_query($conn, $sqlinsertabsent);

                  echo "<div 
                    style ='font-size:14px;
                            text-align:center;
                            background-color:#e74c3c;
                            color:#ecf0f1;
                            padding-top:2px;
                            padding-bottom:2px;
                            '>".$studname." has 3 absents in this subject.</div>"; 
            
                  $msg = "Warning Message";
                   $msg = wordwrap($msg,70);

              }
          }
      }
       
            }
        }else{

      }



        $sql = "SELECT * FROM tblsubschedule WHERE classno = '$classno' AND day = '$daycut' AND datesub = '$datenow'  AND timestart <= '$timenow' AND timeend >= '$timenow'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
             // output data of each row
              while($row = mysqli_fetch_assoc($result)) {
                $timestart = $row['timestart'];
                $timeend = $row['timeend'];

                $times12format = date('h:i:s a', strtotime($timestart));
                $timee12format = date('h:i:s a', strtotime($timeend)); 


             echo "<tr>
                    <td>Section : </td>
                    <td>". $row['section'] ."</td>
                  </tr>
                  <tr>
                    <td>Subject : </td>
                    <td>".$row['description']."</td>
                  </tr>
                  <tr>
                    <td>Time : </td>
                    <td>".$times12format.' - '.$timee12format."</td>
                  </tr>
                  ";
              }

      }else{
                    
        $sql = "SELECT * FROM tblschedule WHERE classno = '$classno' AND day = '$daycut'  AND timestart <= '$timenow' AND timeend >= '$timenow'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
             // output data of each row
              while($row = mysqli_fetch_assoc($result)) {
                $timestart = $row['timestart'];
                $timeend = $row['timeend'];

                $times12format = date('h:i:s a', strtotime($timestart));
                $timee12format = date('h:i:s a', strtotime($timeend)); 


             echo "<tr>
                    <td>Section : </td>
                    <td>". $row['section'] ."</td>
                  </tr>
                  <tr>
                    <td>Subject : </td>
                    <td>".$row['description']."</td>
                  </tr>
                  <tr>
                    <td>Time : </td>
                    <td>".$times12format.' - '.$timee12format."</td>
                  </tr>
                  ";
              }
          }else{
               unset($_SESSION['entryno']);
               //header("LOCATION:schedulepanel.php");
          }
      }
    ?>          
                
      
    </table>
    </div>
    <div style="overflow-x:auto;overflow-y:auto;">
    <form action="submitattendance.php" method="POST">
      <table>
      <tr>
        <th>No.</th>
        <th>Fullname</th>   
        <th width='30%' colspan="3">Status</th>
      </tr> 
    <?php
    // require_once('checktime.php');
      include '../config.php';

      date_default_timezone_set("Asia/Manila"); 

       $sqltime = "SELECT NOW() AS DATE_TIME, DAYNAME(NOW()) AS DYNAME FROM DUAL";
       $restime = mysqli_query($conn, $sqltime);
    if (mysqli_num_rows($restime)){ while ($rowtime = mysqli_fetch_array($restime)) { $deftime=$rowtime['DATE_TIME']; $defnow=$rowtime['DYNAME']; } }
       $daynow = $defnow;
       $daycut = "";
       if (($daynow=="Thursday") || ($daynow=="Sunday") || ($daynow=="TH") || ($daynow=="Thu") ) {
         $daycut = substr($daynow,0,2);
     
       } else {
        $daycut = substr($daynow,0,2);    
      }

        $datenow = substr($deftime,0,10);
        $timenow = substr($deftime,11,8);
        $classno = $_SESSION['classno'];
        $status ="";
        $cnt = 0;
              
   

        $sql = "SELECT * FROM tblstudent WHERE classno = '$classno'";
        $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
             // output data of each row
       while($row = mysqli_fetch_assoc($result)){

         $studentid = $row['studentid'];

         $timestarts = $_SESSION['timestart'];
         $timeends = $_SESSION['timeend'];


         $sql1 = "SELECT * FROM tblatt WHERE dateatt = '$datenow' 
          AND dayatt = '$daycut' AND studentid = '$studentid' AND classno = '$classno'
          AND timein <= '$timestarts' AND timeout >= '$timeends'";
          $result1 = mysqli_query($conn, $sql1);
          if (mysqli_num_rows($result1) > 0) {
          while($row1 = mysqli_fetch_assoc($result1)){                           
              $status = $row1['status'];
              $remarks = $row1['remarks'];
              $studentid = $row1['studentid'];               
              $_SESSION['trigerer'] = 'true';
           

  if($status == 'Present'){
                $rowcnt = $cnt += 1;
              
                echo "<tr style='width:100%'>";
                echo "<td>".$rowcnt.".</td>";
                echo "<td>".$row['studentname']."</td>";
                echo  "<td><input type='radio' name='".$row['studentid']."' value='Present' Checked>Present</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Absent'>Absent</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Late'>Late</td></tr>";
             }elseif($status == 'Late'){
                 $rowcnt = $cnt += 1;
                echo "<tr style='width:100%'>";
                echo "<td>".$rowcnt.".</td>";
                echo "<td>".$row['studentname']."</td>";
                echo  "<td><input type='radio' name='".$row['studentid']."' value='Present'>Present</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Absent'>Absent</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Late' checked>Late</td></tr>";
             }elseif ($status == 'Absent') {       
                $rowcnt = $cnt += 1;
                echo "<tr style='width:100%'>";
                echo "<td>".$rowcnt.".</td>";
                echo "<td>".$row['studentname']."</td>";
                echo  "<td><input type='radio' name='".$row['studentid']."' value='Present'>Present</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Absent' Checked>Absent</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Late' >Late</td></tr>";

                    }

                            
          }

        }else{
                $rowcnt = $cnt += 1;
           
                echo "<tr style='width:100%'>";
                echo "<td>".$rowcnt."</td>";
                echo "<td>".$row['studentname'].".</td>";
                echo  "<td><input type='radio' name='".$row['studentid']."' value='Present' Required>Present</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Absent'>Absent</td>
                      <td><input type='radio' name='".$row['studentid']."' value='Late'>Late</td></tr>";}
       
                }
    
}
              
      ?>
  
   <tr>
     <td colspan="7">
<?php
      if(!isset($_SESSION['trigerer'])){
        $_SESSION['trigerer'] = 'false';
      }
      if($_SESSION['trigerer'] == 'true'){
        echo "<input style='background-color:#27ae60' class='button submitbut' type='submit' name='submitAtt' value='Update'>";
      }else{
        echo "<input  class='button submitbut' type='submit' name='submitAtt' value='Submit'>";
      }
    
?>

     </td>
   </tr>
    </table>
    </form>


  </div>
     
   </div>

  </div>

  <script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

  <script src="js/myajax.js"></script>
   <script>
       function closeNav() {
        if(x.matches){
          document.getElementById("mySidenav").style.width = "0";
        }else{
          document.getElementById("mySidenav").style.width = "200px";
        }     
        }
         function openNav() {
          document.getElementById("mySidenav").style.width = "200px" ; 
        }
        var x = window.matchMedia("(max-width: 450px)")
         myFunction(x) // Call listener function at run time
         x.addListener(myFunction) // Attach listener function on state changes
  </script>
</body>


</html> 
