<?php 
	include '../config.php';
  session_start();
	date_default_timezone_set("Asia/Manila"); 
	//SELECT NOW() AS DATE_TIME FROM DUAL
	$sqltime = "SELECT NOW() AS DATE_TIME, DAYNAME(NOW()) AS DYNAME FROM DUAL";
	$restime = mysqli_query($conn, $sqltime);
	if (mysqli_num_rows($restime)){ while ($rowtime = mysqli_fetch_array($restime)) { $deftime=$rowtime['DATE_TIME']; $defnow=$rowtime['DYNAME']; } }
	$daynow = $defnow;
	$daycut = "";

  if (($daynow=="Thursday") || ($daynow=="Sunday") || ($daynow=="TH") || ($daynow=="Thu") ) {
    $daycut = substr($daynow,0,2);
  } else {
    $daycut = substr($daynow,0,2);    
  }

 	$datenow = substr($deftime,0,10);
	$timenow = substr($deftime,11,8);
	echo $datenow." ".$timenow."<br>";
 	$faid =$_SESSION['facid']; 

  if(isset($_POST['submit'])){
    $classno = $_POST['viewing'];
  }else{
    $classno="";
  } 
  
  //IF THE SESSION CLASSNO IS SET ... 

  $_SESSION['classno'] = $classno;
  

  $classnum = $_SESSION['classno'];
  $fullname = $_SESSION['fullname'];


  echo  "classno ".$classnum."<br>";
  echo $faid."<br>";
  echo $timenow."<br>";

  $sql = "SELECT * FROM tblsubschedule WHERE (facultyid = '$faid' OR fullname = '$fullname') AND (classno = '$classnum' AND timestart < '$timenow' AND timeend > '$timenow' AND datesub = '$datenow')";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
             // output data of each row
      while($row = mysqli_fetch_assoc($result)){

    if($_SESSION['trigerer'] == 'true'){


     }else{
          $sqlinsert = "INSERT INTO tbllog (datelog,facultyid,timein,timeout,fullname,classno,term,dept,status) 
                  VALUES ('$datenow','$faid','$timenow','','$fullname','$classno','$term','sub' AND flag = '1')";
                  mysqli_query($conn, $sqlinsert);
    }
          header("location:attendancepanel.php");                
          //$_SESSION['classno'] = $row['classno'];
          $_SESSION['term'] = $row['term'];
          $_SESSION['entryno'] = $row['entryno'];
       }

  }else{
   echo "fac id ".$faid."<br>";
   echo "fullname ".$fullname."<br>";
   echo "classnum ".$classnum."<br>";
   echo "time na mo ".$timenow."<br>";


   $sql = "SELECT * FROM tblschedule WHERE (facultyid = '$faid' OR fullname = '$fullname') AND (classno = '$classnum' AND timestart <= '$timenow' AND timeend >= '$timenow' AND day = '$daycut' AND flag = '1')";
   $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {

          $sqldeletelog = "DELETE FROM tbllog WHERE datelog = '$datenow ' AND facultyid ='$faid' AND fullname = '$fullname' AND classno = '$classno'";
                  mysqli_query($conn, $sqldeletelog);

          $sqlinsert = "INSERT INTO tbllog (datelog,facultyid,timein,timeout,fullname,classno,term,dept,status) 
                  VALUES ('$datenow','$faid','$timenow','','$fullname','$classno','$term','','Regular')";
                  mysqli_query($conn, $sqlinsert);
    
      while($row = mysqli_fetch_assoc($result)){
          header("location:attendancepanel.php");
          $_SESSION['timestart'] = $row['timestart'];
          $_SESSION['timeend'] = $row['timeend'];                
          $_SESSION['classno'] = $row['classno'];
          $_SESSION['description'] = $row['description'];
          $_SESSION['term'] = $row['term'];
          $_SESSION['entryno'] = $row['entryno'];
          echo "nagana!";
           }
         }else{               
          unset($_SESSION['entryno']);
          unset($_SESSION['ifout']);
          echo "nagana!---";
          header("location:schedulepanel.php");
      }
}
?>