<?php
  		include '../config.php';
      session_start();

        date_default_timezone_set("Asia/Manila"); 
        //SELECT NOW() AS DATE_TIME FROM DUAL
        $sqltime = "SELECT NOW() AS DATE_TIME, DAYNAME(NOW()) AS DYNAME FROM DUAL";
        $restime = mysqli_query($conn, $sqltime);
        if (mysqli_num_rows($restime)){ while ($rowtime = mysqli_fetch_array($restime)) { $deftime=$rowtime['DATE_TIME'];
         $defnow=$rowtime['DYNAME']; } }
         $daynow = $defnow;
         $daycut = "";

      if (($daynow=="Thursday") || ($daynow=="Sunday") || ($daynow=="TH") || ($daynow=="Thu") ) {
         $daycut = substr($daynow,0,2);
        } else {
         $daycut = substr($daynow,0,2);    
        }
         $datenow = substr($deftime,0,10);
         $timenow = substr($deftime,11,8);

      $classno = $_SESSION['classno'];
      $faid = $_SESSION['facid'];
      $term = $_SESSION['term'];
      $fullname = $_SESSION['fullname']; 
      echo $term;
      
	    $sql = "SELECT * FROM  tblstudent WHERE classno = '$classno'";
      $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
             // output data of each row
      while($row = mysqli_fetch_assoc($result)) {
        $studname = $row["studentname"];     
        $studid = $row["studentid"];
        echo $studid ."<br>";		
 				$ATT = $_POST[$studid];
 				echo $ATT."<br>";
 			$remarks= "";
        //Require('absentcounter.php');

if($_SESSION['trigerer'] == 'true'){    
        $sql = "UPDATE tblatt SET status = '$ATT',remarks = '$remarks' WHERE studentid = '$studid' AND dayatt = '$daycut' AND dateatt = '$datenow' AND classno = '$classno'";
          if(mysqli_query($conn, $sql)){
                $_SESSION['msgupdate'] = 'true';
                $_SESSION['msginsert'] = '';
              }else{
                $_SESSION['msgupdate'] = 'false';
              }              
           header("LOCATION:attendancepanel.php"); 
           
      }else{      
      $sqlflagupd = "UPDATE tblschedule SET status = 'checked' 
                    WHERE facultyid = '$faid' AND classno = '$classno' AND day = '$daycut' AND timestart < '$timenow' AND timeend > '$timenow'";
                 mysqli_query($conn, $sqlflagupd);

      
            $timestarts = $_SESSION['timestart'];
            $timeends = $_SESSION['timeend'];

            echo "facultyid ".$faid."<br>";
            echo "studentname ".$studname."<br>";
            echo "datenow ".$datenow."<br>";
            echo "daycut ".$daycut."<br>";
            echo "timestart ".$timestarts."<br>";
            echo "timeends ".$timeends."<br>";
            echo "attendance ".$ATT."<br>";
            echo "remarks ".$remarks."<br>";                 
            echo "classno ".$classno."<br>";
       
            $sql = "INSERT INTO tblatt(studentid,facultyid,studentname,dateatt,dayatt,timein,timeout,status,remarks,classno,term) 
                VALUES ('$studid','$faid','$studname','$datenow','$daycut','$timestarts','$timeends','$ATT','$remarks','$classno','$term')";
      		     if(mysqli_query($conn, $sql)){
                $_SESSION['msginsert'] = 'true';
                $_SESSION['msgupdate'] = '';          
              }else{
                $_SESSION['msginsert'] = 'false';
              } 
                 header("LOCATION:attendancepanel.php");                               
         }        
      }
   
    }else{
}       

?>