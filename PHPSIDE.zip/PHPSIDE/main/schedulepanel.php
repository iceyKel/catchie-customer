<?php
session_start();
if(!isset($_SESSION['facid'])){
  header('location:../index.php');
}

/*if(isset($_SESSION['entryno'])){
  header('location:checktime.php');
}*/
 ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="icon" type="image/png" href="image/stilogo.jpg"/>
<style>

</style>
  
</head>
<body>

<!--<div id="mySidenav" class="sidenav">
  <div class="logo">        
  </div> 
    <a href="schedulepanel.php" onclick="closeNav()"><i class="fa fa-calendar-o"></i> Check Schedule</a>
    <a href="checktime.php" onclick="closeNav()"><i class="fa fa-calendar-check-o"></i> Check Attendance</a>
    <a href="signout.php" onclick="closeNav()"><i class="fa fa-sign-out"></i> Sign-Out</a>
    <a href="#contact" onclick="closeNav()"><i class="fa fa-cloud"></i> About</a>
</div>-->

  <div class="main">

    <table class="header">
      <!--<td><span style="font-size:30px;cursor:pointer" onclick="openNav()"><i class="fa fa-sign-out"></i></span></td>-->
      <td><span style="font-size:30px;cursor:pointer"><a href="signout.php" style="text-decoration: none;color: white"><i class="fa fa-sign-out"></i></a></span></td>
  
      <td style="width: 70%;">Schedule</td><td style="font-size: 8px">Faculty ID :</td><td style="font-size: 8px">
        <?php echo $_SESSION['facid'];?>          
        </td><td style="font-size: 8px">Faculty Name :</td><td style="font-size: 8px">
       <?php echo $_SESSION['fullname'];?>         
        </td>
    </table>
      
   <form>
  <div>
    <div>
     
    </div>

    <div class='conmain' style="overflow-x:auto;">
      <form>
      </form>

      <table>
      <tr>
  
        <th>Description</th>
        <th>Room</th>
        <th>Day</th>
        <th>Time</th>
        <th width="10%">Action</th>
      </tr>
      
        <?php
        include '../config.php';

        date_default_timezone_set("Asia/Manila"); 
        //SELECT NOW() AS DATE_TIME FROM DUAL
        $sqltime = "SELECT NOW() AS DATE_TIME, DAYNAME(NOW()) AS DYNAME FROM DUAL";
        $restime = mysqli_query($conn, $sqltime);
        if (mysqli_num_rows($restime)){ while ($rowtime = mysqli_fetch_array($restime)) { $deftime=$rowtime['DATE_TIME'];
         $defnow=$rowtime['DYNAME']; } }
         $daynow = $defnow;
         $daycut = "";

      if (($daynow=="Thursday") || ($daynow=="Sunday") || ($daynow=="TH") || ($daynow=="Thu") ) {
         $daycut = substr($daynow,0,2);
        } else {
         $daycut = substr($daynow,0,2);    
        }
         $datenow = substr($deftime,0,10);
         $timenow = substr($deftime,11,8);

         $faid = $_SESSION['facid'];          
         $fullname = $_SESSION['fullname']; 

          ///////////////////////////

           $sql = "SELECT * FROM tblsubschedule WHERE facultyid = '$faid' OR fullname = '$fullname' AND datesub = '$datenow' ORDER BY timestart";
         $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
             // output data of each row
              while($row = mysqli_fetch_assoc($result)){
                $classno = $row["classno"];
                //$_SESSION['entryno'] = $entryno;
                $coursecode = $row["coursecode"];
                $description = $row["description"];       
                $room = $row["room"];
                $day = $row["day"];
                $timestart = $row["timestart"];            
                $timeend = $row["timeend"];  


                $timecutnow = explode(":", $timenow);
                $timecutnow1 = $timecutnow[0];
                $timecutnow2 = $timecutnow[1];
                $timecutnow3 = $timecutnow[2];
                $timetotalnow =  $timecutnow1.$timecutnow2.$timecutnow3;
            
                $timecutstart = explode(":", $timestart);
                $timetotalstart =  $timecutstart[0].$timecutstart[1].$timecutstart[2];
              

                $timecutend = explode(":", $timeend);
                $timetotalend =   $timecutend[0]. $timecutend[1].$timecutend[2];
             

                $times12format = date('h:i:s a', strtotime($timestart));
                $timee12format = date('h:i:s a', strtotime($timeend)); 
                

  if($day == $daycut && $timetotalstart < $timetotalnow && $timetotalend > $timetotalnow){
                
     /*$sql1 = "SELECT * FROM tblatt WHERE facultyid = '$faid' AND dateatt = '$datenow' 
                 AND dayatt = '$daycut' AND classno = '$classno'";*/
                   $result1 = mysqli_query($conn, $sql1);
               if (mysqli_num_rows($result1) > 0) {
                   // output data of each row
                  $_SESSION['trigerer'] = 'true';
          
             
                  echo "<tr style='width:100%'>";
                  echo "<td>".$description."</td>";            
                  echo "<td style='text-align:center'>".$room."</td>";
                  echo "<td style='text-align:center'>".$day."</td>";
                  echo "<td style='text-align:center'>".$times12format." - ". $timee12format . " </td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'>
                          <form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing' value='".$classno."'>
                          <input style='width:100%;background-color:#27ae60' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Edit'>
                          </form></td>
                      </tr>";
  
                

                 }else{
                  $_SESSION['trigerer'] = 'false';
                  echo "<tr style='width:100%'>";
                  echo "<td>".$description."</td>";            
                  echo "<td style='text-align:center'>".$room."</td>";
                  echo "<td style='text-align:center'>".$day."</td>";
                  echo "<td style='text-align:center'>".$times12format." - ". $timee12format . " </td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'>
                          <form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing' value='".$classno."'>
                          <input style='width:100%' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Check'>
                          </form></td>
                      </tr>";
               }

                


          }else{
                 
                  echo "<tr style='width:100%'>";
                  echo "<td>".$description."</td>";            
                  echo "<td style='text-align:center'>".$room."</td>";
                  echo "<td style='text-align:center'>".$day."</td>";
                  echo "<td style='text-align:center'>".$times12format." - ". $timee12format . " </td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'><form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing' value='".$classno."'>
                          <input style='width:100%;background:#95a5a6' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Check'>
                          </form></td>
                      </tr>";
                }

          
              }
          }else{
              
          }       

         ///////////////////////////

         $sql = "SELECT * FROM tblschedule WHERE (facultyid = '$faid' or fullname = '$fullname') AND day = '$daycut' ORDER BY timestart";
         $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
             // output data of each row
              while($row = mysqli_fetch_assoc($result)){
                $classno = $row["classno"];
                //$_SESSION['entryno'] = $entryno;
                $coursecode = $row["coursecode"];
                $flag = $row["flag"];
                $stats = $row["status"];
                $description = $row["description"];       
                $room = $row["room"];
                $day = $row["day"];
                $timestart = $row["timestart"];            
                $timeend = $row["timeend"];  

                $timecutnow = explode(":", $timenow);
                $timecutnow1 = $timecutnow[0];
                $timecutnow2 = $timecutnow[1];
                $timecutnow3 = $timecutnow[2];
                $timetotalnow =  $timecutnow1.$timecutnow2.$timecutnow3;
            
                $timecutstart = explode(":", $timestart);
                $timetotalstart =  $timecutstart[0].$timecutstart[1].$timecutstart[2];
              
                $timecutend = explode(":", $timeend);
                $timetotalend =   $timecutend[0]. $timecutend[1].$timecutend[2];
             
                $times12format = date('h:i:s a', strtotime($timestart));
                $timee12format = date('h:i:s a', strtotime($timeend)); 

     if($day == $daycut && $timetotalstart < $timetotalnow && $timetotalend > $timetotalnow){
          
               $sql1 = "SELECT * FROM tbllog WHERE facultyid = '$faid' AND datelog = '$datenow' AND classno = '$classno'";
                   $result1 = mysqli_query($conn, $sql1);
               if (mysqli_num_rows($result1) > 0) {
                   // output data of each row
                
                 /* if($stats == 'checked'){
                  echo "<tr style='width:100%'>";
                  echo "<td>".$description."</td>";            
                  echo "<td style='text-align:center'>".$room."</td>";
                  echo "<td style='text-align:center'>".$day."</td>";
                  echo "<td style='text-align:center'>".$times12format." - ". $timee12format . " </td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'><form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing' value='".$classno."'>
                          <input style='width:100%;background:#95a5a6' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Checked' Disabled>
                          </form></td>
                      </tr>";

                  }else{*/
                  echo "<tr style='width:100%'>";
                  echo "<td>".$description."</td>";            
                  echo "<td style='text-align:center'>".$room."</td>";
                  echo "<td style='text-align:center'>".$day."</td>";
                  echo "<td style='text-align:center'>".$times12format." - ". $timee12format . " </td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'>
                          <form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing' value='".$classno."'>
                          <input style='width:100%;background-color:#27ae60' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Edit'>
                          </form></td>
                      </tr>";
  
                  //}

                 }else{
                  $sqlflagupd = "UPDATE tblschedule SET status = '' WHERE facultyid = '$faid' AND classno = '$classno' AND day = '$daycut' AND timestart <= '$timenow' AND timeend >= '$timenow'";
                      mysqli_query($conn, $sqlflagupd);

                  $_SESSION['trigerer'] = 'false';
                  echo "<tr style='width:100%'>";
                  echo "<td>".$description."</td>";            
                  echo "<td style='text-align:center'>".$room."</td>";
                  echo "<td style='text-align:center'>".$day."</td>";
                  echo "<td style='text-align:center'>".$times12format." - ". $timee12format . " </td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'>
                          <form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing' value='".$classno."'>
                          <input style='width:100%' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Check'>
                          </form></td>
                      </tr>";
               }
        }else{                
                  echo "<tr style='width:100%'>";
                  echo "<td>".$description."</td>";            
                  echo "<td style='text-align:center'>".$room."</td>";
                  echo "<td style='text-align:center'>".$day."</td>";
                  echo "<td style='text-align:center'>".$times12format." - ". $timee12format . " </td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'><form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing' value='".$classno."'>
                          <input style='width:100%' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Check'>
                          </form></td>
                      </tr>";
                }      
              }
          }else{

            echo "<tr style='width:100%'>";
                  echo "<td>--</td>";            
                  echo "<td style='text-align:center'>--</td>";
                  echo "<td style='text-align:center'>--</td>";
                  echo "<td style='text-align:center'>--</td>";              
                 //echo "<td><a style='font-size:12px;' href = ''>Check Attendance</a></tr>";
                  echo "<td style='text-align:center'><form action='checktime.php' method = 'POST'>
                          <input type='hidden' name='viewing'>
                          <input style='width:100%' class='buttonforcheck submitbutforcheck' type= 'submit' name = 'submit' value = 'Check' Disabled>
                          </form></td>
                      </tr>";
               
          }       
          ?>
      
   <tr>
   </tr>
    </table>

  </div>
     
   </div>
   </form>
  <div class="footer">
      <div id = 'servertime'></div>
      <a style="color: #ecf0f1;" href="reportmessagepanel.php">Report problem</a>
    </div>
  </div>
  <script src="js/myajax.js"></script>
   <script>
      var myVar = setInterval(myTimer, 1000);

    function myTimer() {
      var d = new Date();
      document.getElementById("servertime").innerHTML = "SERVER TIME : " + d.toLocaleTimeString();
      }
   </script>
   <script>

       function closeNav() {
        if(x.matches){
          document.getElementById("mySidenav").style.width = "0";
        }else{
          document.getElementById("mySidenav").style.width = "200px";
        }     
        }
         function openNav() {         
          document.getElementById("mySidenav").style.width = "200px" ; 
        }
         var x = window.matchMedia("(max-width: 450px)")
         myFunction(x) // Call listener function at run time
         x.addListener(myFunction) // Attach listener function on state changes
  </script>
</body>
</html>
