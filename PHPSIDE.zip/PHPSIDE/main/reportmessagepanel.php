<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>	
<div style="text-align: center;position: relative;">
	<form action = "reportmessagepanel.php" method="POST">
		<p style="font-size:25px">Your message</p>
		<textarea style="width:50%;font-size: 18px" name="msg" placeholder="Please specify your room subject and your problem."></textarea><br>
		<input style="font-size: 18px;width: 50%;" type="submit" name="submit" value="Send">
	</form>
	<a style="font-size: 12px" href="schedulepanel.php">Cancel</a>
</div>
</body>
</html>
<?php 
if(isset($_POST['submit'])){
 include '../config.php';
 session_start();
 $facultyname = $_SESSION['fullname'];
 $message = mysqli_real_escape_string($conn,$_POST['msg']);
 $sql = "INSERT INTO tblreportmessages (facultyname,message) VALUES ('$facultyname','$message')";
 if(mysqli_query($conn, $sql)){
 	echo "<center>Message sent!</center>";
 }else{
 	echo "<center>Message failed to send!</center>";
 }
}
 ?>