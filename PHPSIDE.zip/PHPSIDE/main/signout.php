<?php
session_start();
//session_unset();
//unset($_SESSION['facid']);
//unset($_SESSION['fullname']);
session_destroy(); 
header('location: ../index.php');
?>