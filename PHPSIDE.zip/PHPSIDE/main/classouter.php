<?php
include '../config.php';
session_start();
date_default_timezone_set("Asia/Manila"); 
     
$sqltime = "SELECT NOW() AS DATE_TIME, DAYNAME(NOW()) AS DYNAME FROM DUAL";
$restime = mysqli_query($conn, $sqltime);
if (mysqli_num_rows($restime)){ while ($rowtime = mysqli_fetch_array($restime)) { $deftime=$rowtime['DATE_TIME'];
  $defnow=$rowtime['DYNAME']; } }
    $daynow = $defnow;
    $daycut = "";

  if (($daynow=="Thursday") || ($daynow=="Sunday") || ($daynow=="TH") || ($daynow=="Thu") ) {
      $daycut = substr($daynow,0,2);
        } else {
      $daycut = substr($daynow,0,2);    
     }
      $datenow = substr($deftime,0,10);
      $timenow = substr($deftime,11,8);

      $classno = $_SESSION['classno'];
      $faid = $_SESSION['facid'];
      $term = $_SESSION['term'];
      $fullname = $_SESSION['fullname']; 

      echo $classno."<br>";
      echo $faid."<br>";
      echo $timenow."<br>";
      echo $datenow;
      //header("LOCATION:schedulepanel.php");
      unset($_SESSION['entryno']);
      unset($_SESSION['classno']);

      $_SESSION['ifout'] = 'true';

      $sqlflagupd = "UPDATE tblschedule SET status = 'checked' 
                  WHERE facultyid = '$faid' AND classno = '$classno' AND day = '$daycut' AND timestart <= '$timenow' AND timeend >= '$timenow'";
              if(mysqli_query($conn, $sqlflagupd)){
               echo "updated";
              }else{
                echo "not update";
              }
      $sql = "UPDATE tbllog SET timeout = '$timenow' WHERE facultyid = '$faid' AND classno = '$classno' AND datelog = '$datenow'";
              if(mysqli_query($conn, $sql)){
                  echo "updated";
              }else{
                echo "not update";
              }
              header("LOCATION:schedulepanel.php");

?>